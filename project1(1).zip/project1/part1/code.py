import jsontrips

"""
The skeleton file. You should implement your code here. Make sure that the code you write here runs properly
when called by the test1.py file in the root directory.`
"""

def check_subsumption(type1, type2):
   """1) Take two types in the TRIPS ontology as inputs. If one type is a subtype of the other, return the tuple
         (True, type), where type is the type that is a subtype. Otherwise, return the tuple (False, None)."""
   # IMPLEMENT FUNCTION HERE
   pass